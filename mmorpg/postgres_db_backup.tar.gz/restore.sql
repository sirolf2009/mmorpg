--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.owns DROP CONSTRAINT owns_user_name_fkey;
ALTER TABLE ONLY public.stores DROP CONSTRAINT fk_name;
ALTER TABLE ONLY public.owns DROP CONSTRAINT fk_name;
ALTER TABLE ONLY public.stores DROP CONSTRAINT fk_address;
ALTER TABLE ONLY public.stores DROP CONSTRAINT stores_address_user_name_key;
ALTER TABLE ONLY public.users DROP CONSTRAINT pk_username;
ALTER TABLE ONLY public.owns DROP CONSTRAINT pk_owns;
ALTER TABLE ONLY public.characters DROP CONSTRAINT pk_name;
ALTER TABLE ONLY public.servers DROP CONSTRAINT pk_address;
DROP TABLE public.users;
DROP TABLE public.stores;
DROP TABLE public.servers;
DROP TABLE public.owns;
DROP TABLE public.characters;
DROP EXTENSION adminpack;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: mmorpg
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO mmorpg;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: mmorpg
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: characters; Type: TABLE; Schema: public; Owner: mmorpg; Tablespace: 
--

CREATE TABLE characters (
    name character varying NOT NULL,
    class_type character varying,
    race character varying,
    level integer
);


ALTER TABLE public.characters OWNER TO mmorpg;

--
-- Name: owns; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE owns (
    name character varying NOT NULL,
    user_name character varying NOT NULL
);


ALTER TABLE public.owns OWNER TO postgres;

--
-- Name: servers; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE servers (
    address character varying NOT NULL,
    name character varying,
    location character varying,
    max_users integer,
    connected_users integer
);


ALTER TABLE public.servers OWNER TO postgres;

--
-- Name: stores; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE stores (
    address character(16),
    user_name character(255)
);


ALTER TABLE public.stores OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: mmorpg; Tablespace: 
--

CREATE TABLE users (
    balance double precision,
    character_slots integer,
    months_payed integer,
    banned boolean,
    first_name character varying,
    user_name character varying NOT NULL,
    last_name character varying,
    iban character varying,
    last_payment character varying,
    password character varying
);


ALTER TABLE public.users OWNER TO mmorpg;

--
-- Data for Name: characters; Type: TABLE DATA; Schema: public; Owner: mmorpg
--

COPY characters (name, class_type, race, level) FROM stdin;
\.
COPY characters (name, class_type, race, level) FROM '$$PATH$$/2001.dat';

--
-- Data for Name: owns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY owns (name, user_name) FROM stdin;
\.
COPY owns (name, user_name) FROM '$$PATH$$/2003.dat';

--
-- Data for Name: servers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY servers (address, name, location, max_users, connected_users) FROM stdin;
\.
COPY servers (address, name, location, max_users, connected_users) FROM '$$PATH$$/2002.dat';

--
-- Data for Name: stores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY stores (address, user_name) FROM stdin;
\.
COPY stores (address, user_name) FROM '$$PATH$$/2004.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: mmorpg
--

COPY users (balance, character_slots, months_payed, banned, first_name, user_name, last_name, iban, last_payment, password) FROM stdin;
\.
COPY users (balance, character_slots, months_payed, banned, first_name, user_name, last_name, iban, last_payment, password) FROM '$$PATH$$/2005.dat';

--
-- Name: pk_address; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY servers
    ADD CONSTRAINT pk_address PRIMARY KEY (address);


--
-- Name: pk_name; Type: CONSTRAINT; Schema: public; Owner: mmorpg; Tablespace: 
--

ALTER TABLE ONLY characters
    ADD CONSTRAINT pk_name PRIMARY KEY (name);


--
-- Name: pk_owns; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY owns
    ADD CONSTRAINT pk_owns PRIMARY KEY (name, user_name);


--
-- Name: pk_username; Type: CONSTRAINT; Schema: public; Owner: mmorpg; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT pk_username PRIMARY KEY (user_name);


--
-- Name: stores_address_user_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY stores
    ADD CONSTRAINT stores_address_user_name_key UNIQUE (address, user_name);


--
-- Name: fk_address; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY stores
    ADD CONSTRAINT fk_address FOREIGN KEY (address) REFERENCES servers(address);


--
-- Name: fk_name; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY owns
    ADD CONSTRAINT fk_name FOREIGN KEY (name) REFERENCES characters(name);


--
-- Name: fk_name; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY stores
    ADD CONSTRAINT fk_name FOREIGN KEY (user_name) REFERENCES users(user_name);


--
-- Name: owns_user_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY owns
    ADD CONSTRAINT owns_user_name_fkey FOREIGN KEY (user_name) REFERENCES users(user_name);


--
-- Name: public; Type: ACL; Schema: -; Owner: mmorpg
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM mmorpg;
GRANT ALL ON SCHEMA public TO mmorpg;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

